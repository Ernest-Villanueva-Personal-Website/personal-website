const now = "Ernest ";
console.log ("Who enjoys class? ... " + now);
//This should meet the requirements for this project 